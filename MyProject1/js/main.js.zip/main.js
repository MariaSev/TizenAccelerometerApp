
////////////////////////////////////////////////// Database
//if (!window.indexedDB) {
//    window.alert("IndexDB not supported");
//}
//
//var WriteToDB = "false";
//var Object_DB = 0;
//
//function CreateDB() {
//	// Открываем базу данных
//	var request = window.indexedDB.open("TizenDB", 1);
//	var db;
//	
//	alert("1");
//	// Обработчик ошибок/////////////////
//	request.onerror = function(event) {
//		alert("err");
//	};
//	
//	// В случае успеха//////////////////////
//	request.onsuccess = function(event) {
//		db = event.target.result;
//		db.onerror = function(event) {
//			  // все ошибки выводим в alert
//			  alert("Database error: " + event.target.errorCode);
//		};
//		
//		alert("in success");
//	
//	};
//	
//	// Обновление ////////////////////////////
//	request.onupgradeneeded = function(event) {
//		alert("ok");
//		db = event.target.result;
//		// Создаем хранилище объектов для этой базы данных
//		var objectStore = db.createObjectStore("tizenStore", {keyPath: "key"});
//		objectStore.createIndex("data", "data", {unique: true});
//		objectStore.createIndex("number", "number", {unique: true});
//		WriteToDB = "true";
//		Object_DB = objectStore;
//		alert("after_function");
//	};
//}

//CreateDB();


/*var indexedDB 	  = window.indexedDB,
	IDBTransaction  = window.IDBTransaction,
	baseName 	  = "filesBase",
	storeName 	  = "data";

function logerr(err){
	console.log(err);
}

function connectDB(f){
	var request = indexedDB.open(baseName, 1);
	request.onerror = logerr;
	request.onsuccess = function(){
		//f(request.result);
	}
	request.onupgradeneeded = function(e){
		console.log("~~~~~~~onupgradeneeded execute~~~~~~~");
		e.currentTarget.result.createObjectStore(storeName, { keyPath: "key" });
		//connectDB(f);
		f(request.result);
	}
}

function getFile(file, f){
	connectDB(function(db){
		var request = db.transaction([storeName], "readonly").objectStore(storeName).get(file);
		request.onerror = logerr;
		request.onsuccess = function(){
			f(request.result ? request.result : -1);
		}
	});
}

function getStorage(f){
	connectDB(function(db){
		var rows = [],
			store = db.transaction([storeName], "readonly").objectStore(storeName);

		store.openCursor().onsuccess = function(e) {
			var cursor = e.target.result;
			if(cursor){
				rows.push(cursor.value);
				cursor.continue();
			}
			else {
				f(rows);
			}
		};
	});
}

function setFile(file){
	connectDB(function(db){
		var request = db.transaction(storeName, "readwrite").objectStore(storeName).put(file);
		request.onerror = logerr;
		request.onsuccess = function(){
			console.log(request.result); 
			return request.result;
		}
	});
}

function delFile(file){
	connectDB(function(db){
		var request = db.transaction([storeName], "readwrite").objectStore(storeName).delete(file);
		request.onerror = logerr;
		request.onsuccess = function(){
			console.log("File delete from DB:", file);
		}
	});
}
*/

/////////////////////////////////////////////////////////////////////////////////////////////////////////////

	var baseName 	  = "filesBase";
	var storeName 	  = "data";
	
var tizenDB= {};            
var request;  
var objStore;

function callInit (event){                  
	tizenDB.db= event.target.result;                 
	objStore= tizenDB.db.createObjectStore(storeName, {keyPath: "key"});                
          
};

function setData(sensorData){
	objStore.transaction.oncomplete= function(ev){                    
		var trans= tizenDB.db.transaction(storeName, "readwrite");                       
		var tizenStore= trans.objectStore(storeName);                      
		//var data= {"key" : new Date().getTime(),"text" : "Tizen-" + Math.random()};   
		var request= tizenStore.put(sensorData);// Сохраняем данные
		request.onsuccess= function(event) {                    
			tizenDB.db.objectStoreId= request.result; 
			console.log(request.result); 
			//var data = tizenStore.get(tizenDB.db.objectStoreId);
			//var data= tizenStore.delete(tizenDB.db.objectStoreId);
				// Удаляет запись по ключу
			data.onsuccess= function(event) {                            
				console.log(data);                        
			}                    
		};
	};
}
// //// Get accelerometer data
var Start = 0;

var accelerCapability = tizen.systeminfo.getCapability ('http://tizen.org/feature/sensor.accelerometer');
if (accelerCapability === true) {
	var accelerationSensor = tizen.sensorservice.getDefaultSensor("ACCELERATION");
}

function onGetSuccessCB(sensorData)
{
    console.log("######## Get acceleration sensor data ########");
    console.log("x: " + sensorData.x);
    console.log("y: " + sensorData.y);
    console.log("z: " + sensorData.z);
}

function onerrorCB(error)
{
    console.log("error occurred: " + error.message);
}

function onsuccessCB()
{
    console.log("acceleration sensor start");
    accelerationSensor.getAccelerationSensorData(onGetSuccessCB, onerrorCB);
}

var count_the_data = 0;
function onchangedCB(sensorData) {
	if(WriteToDB == "true") {
		var now = new Date();
		console.log(now);
		var Data_to_write = {"key": now, "number": count_the_data, "x": sensorData.x, "y": sensorData.y, "z": sensorData.z};
		count_the_data+=1;
		// /////////////////////////setFile(Data_to_write);
		setData(Data_to_write);
		alert("set data to db");
	}
	
    console.log('sensor data: ' + sensorData.x);
    console.log('sensor data: ' + sensorData.y);
    console.log('sensor data: ' + sensorData.z);
    
    document.getElementById('accel_x').innerHTML = '<p> x:'+ sensorData.x+'</p>';
    document.getElementById('accel_y').innerHTML = '<p> y:'+ sensorData.y+'</p>';
    document.getElementById('accel_z').innerHTML = '<p> z:'+ sensorData.z+'</p>';
    
}
accelerationSensor.setChangeListener(onchangedCB, 10);
// //////////////////////////////////////////////////////////////////////////////////////

// alert(navigator.onLine ? "true" : "false");

function Work() {
	if(Start === 0) {
		if(navigator.onLine) { // If internet connection false. Write data to
								// database// do negative
			WriteToDB = "true";
			request =  window.indexedDB.open(baseName, 1);
			request.onupgradeneeded= callInit(event);
			Start = 1;
			document.getElementById('strt').innerHTML = "<span>Stop read accelerometer data</span>";
			document.getElementById('acceler_data').innerHTML = '<p> </p>';
			accelerationSensor.start(onsuccessCB);
		}
		
		// else {} if internet connection true
	}
	else {
		Start = 0;
		document.getElementById('strt').innerHTML = '<span>Start read accelerometer data</span>';
		WriteToDB = "false";
		accelerationSensor.stop();
		document.getElementById('acceler_data').innerHTML = '<p> Click the bottom to start read accelerometer data</p>';
	}
}
 // Work();





